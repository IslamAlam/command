.. currentmodule:: example_numpy

==============
Introduction
==============

.. automodule:: example_numpy

Overview
===========

.. autosummary::
  
  find_max_sat
  read_file


Function documentation
========================

The find_max function
------------------------
.. autofunction:: find_max_sat

The read_file function
------------------------

.. autofunction:: read_file


