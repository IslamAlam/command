# -*- coding: utf-8 -*-
"""When a commercial ground wants to check its available time slots
to be able to provide the scheduling hot spots during a day. 
A ground station needs to calculate the time overlap between the
visible satellites. 
The data file provided by the flight dynamic team includes the log of the visible satellite for
a specific ground station.

Example
-------
Examples can be given using either the ``Example`` or ``Examples``
sections. Sections support any reStructuredText formatting, including
literal blocks::

    $ python example_numpy.py

Algorithm
-----------
Examples can be given using either the ``Example`` or ``Examples``
sections. Sections support any reStructuredText formatting, including


Section breaks are created with two blank lines. Section breaks are also
implicitly created anytime a new section starts. Section bodies *may* be
indented:

Notes
-----
    This is an example of an indented section. It's like any other section,
    but the body is indented to help it stand out from surrounding text.

If a section is indented, then a section break is created by
resuming unindented text.

Attributes
----------
module_level_variable1 : int
    Module level variables may be documented in either the ``Attributes``
    section of the module docstring, or in an inline docstring immediately
    following the variable.

    Either form is acceptable, but the two should not be mixed. Choose
    one convention to document module level variables and be consistent
    with it.

   

"""



def find_max_sat(file_path):
    """This is the main fucntion which calcute the number of overlapping satellites at a Ground Station.



    The format for a parameter is::

        file_path : a path to a data file
            it can be relative or abs path.

    Parameters
    ----------
    file_path: str
        file path

    Returns
    -------
    None: None
        None


     Examples
    --------
    >>> data = find_max_sat('satellites.dat')
    """
    start_Time, end_Time = read_file(file_path) 
    start_Time = sorted(start_Time)
    end_Time = sorted(end_Time)
    i = 0; j = 0; 
    cur_sat = 0; max_sat = 0; 
    stime = start_Time[0];
    etime = end_Time[0];
    n = len(start_Time);
    while i < n and j < n:
        
        if start_Time[i] <= end_Time[j]:
            cur_sat += 1
            
            if cur_sat > max_sat:
                max_sat = cur_sat
                stime = start_Time[i]
                etime = end_Time[j]
            i += 1;
        else:
            cur_sat -= 1
            j += 1
    # Set the microseconds to three digits
    if isinstance(stime, dt.time):
        stime = stime.strftime('%H:%M:%S.%f')
        stime = stime[:-3]
    if isinstance(etime, dt.time):
        etime = etime.strftime('%H:%M:%S.%f')
        etime = etime[:-3]
        
    print("%s-%s;%d" %(stime, etime, max_sat))
    return None

	

def read_file(file_path):
        """This function read the log file and return the first and second column of the log file as datetime



    The format for a parameter is::

        file_path : a path to a data file
            it can be relative or abs path.

    Parameters
    ----------
    file_path: str
        file path

    Returns
    -------
    first_col: list datetime
        
		
	second_col: list datetime 

     Examples
    ---------
    >>> start_Time, end_Time = read_file('satellites.dat')
    """
	
	


