# -*- coding: utf-8 -*-
"""
Created on Sat Aug 12 17:13:45 2017

@author: Islam Mansour
"""
import numpy as np # import numpy to handle the raw data file
import datetime as dt # import datetime to convert str to datetime format 
import os # import os for the file_path

def find_max_sat(file_path):
    """
        Format the exception with a traceback.

    Parameters
    ----------
    file_path: str
        file path

    Returns
    -------
    None: None
        None

    See Also
    --------
    numpy: a numerical package

    Notes
    -----
    This is an example of autodoc using numpydoc, the Numpy documentation format
    with the numpydoc extension [1]_

    This explanation of the column headers is not complete, for an exhaustive
    specification see [2]_.

    References
    ----------
    .. [1] `numpydoc <https://github.com/numpy/numpy/tree/master/doc/sphinxext>`_, \
        Numpy Documentation.
    .. [2] `Sphinx <http://sphinx-doc.org/domains.html#domains>`_, Sphinx Domains \
        Documentation.

    Examples
    --------
    >>> data = find_max_sat('satellites.dat')
    """
    start_Time, end_Time = read_file(file_path) 
    start_Time = sorted(start_Time)
    end_Time = sorted(end_Time)
    i = 0; j = 0; 
    cur_sat = 0; max_sat = 0; 
    stime = start_Time[0];
    etime = end_Time[0];
    n = len(start_Time);
    while i < n and j < n:
        
        if start_Time[i] <= end_Time[j]:
            cur_sat += 1
            
            if cur_sat > max_sat:
                max_sat = cur_sat
                stime = start_Time[i]
                etime = end_Time[j]
            i += 1;
        else:
            cur_sat -= 1
            j += 1
    # Set the microseconds to three digits
    if isinstance(stime, dt.time):
        stime = stime.strftime('%H:%M:%S.%f')
        stime = stime[:-3]
    if isinstance(etime, dt.time):
        etime = etime.strftime('%H:%M:%S.%f')
        etime = etime[:-3]
        
    print("%s-%s;%d" %(stime, etime, max_sat))
    return None

def read_file(file_path):
        """
        Format the exception with a traceback.

    Parameters
    ----------
    file_path: str
        file path

    Returns
    -------
    first_col: datetime array
        the first column of the data file
    second_col: datetime array
        the second column of the data file

    See Also
    --------
    numpy: a numerical package

    Notes
    -----
    This is an example of autodoc using numpydoc, the Numpy documentation format
    with the numpydoc extension [1]_

    This explanation of the column headers is not complete, for an exhaustive
    specification see [2]_.

    References
    ----------
    .. [1] `numpydoc <https://github.com/numpy/numpy/tree/master/doc/sphinxext>`_, \
        Numpy Documentation.
    .. [2] `Sphinx <http://sphinx-doc.org/domains.html#domains>`_, Sphinx Domains \
        Documentation.

    Examples
    --------
    >>> first_col, second_col = read_file('satellites.dat')
    """
    decodef = lambda x: x.decode("utf-8")
    # start time array, first col.
    first_col=np.genfromtxt(file_path, delimiter=',', skip_header=0, skip_footer=0, usecols=0, dtype=object, converters={0: decodef})
    # end time array, last col.
    second_col=np.genfromtxt(file_path, delimiter=',', skip_header=0, skip_footer=0, usecols=1, dtype=object, converters={1: decodef})
    start_Time = [dt.datetime.strptime(x, "%H:%M:%S.%f").time() for x in first_col]
    second_col   = [dt.datetime.strptime(x, '%H:%M:%S.%f').time() for x in second_col]
    return(first_col, second_col)



user_input = input("Enter the path of the file:")
# C:/Users/isman/Desktop/Satellites_v2/satellites.dat
assert os.path.exists(user_input), "The file is not found, "+str(user_input)

y0 = find_max_sat(user_input)
