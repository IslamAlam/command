def foo():
    """This prints bar"""
    print("bar")

def bar():
    """This prints foo"""
    print("foo")
	
	
def read_file(file_path):
        """This function read the log file and return the first and second column of the log file as datetime

    Function parameters should be documented in the ``Parameters`` section.
    The name of each parameter is required. The type and description of each
    parameter is optional, but should be included if not obvious.

    Parameter types -- if given -- should be specified according to
    `PEP 484`_, though `PEP 484`_ conformance isn't required or enforced.

    If \*args or \*\*kwargs are accepted,
    they should be listed as ``*args`` and ``**kwargs``.

    The format for a parameter is::

        file_path : a path to a data file
            description

            The description may span multiple lines. Following lines
            should be indented to match the first line of the description.
            The ": type" is optional.

            Multiple paragraphs are supported in parameter
            descriptions.

    Parameters
    ----------
    file_path: str
        file path

    Returns
    -------
    None: None
        None

    """
    return None